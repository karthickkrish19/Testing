Advanced LLM module (educational) - pure C# .NET Web API
This project provides a minimal, self-contained implementation of:
- Tokenizer (simple whitespace + char-level BPE-like trainer placeholder)
- EmbeddingService (random embeddings + RoPE precompute)
- Mini Transformer with Multi-Head Attention, LayerNorm, FeedForward
- Controllers to train tokenizer, encode text, get embeddings, and run transformer forward

No third-party libraries used.

Upload your training file at runtime or use the provided sample path:
/mnt/data/c#latestVSCodeAI.txt

To run:
dotnet build
dotnet run

Endpoints:
GET  /api/tokenizer/vocabsize
POST /api/tokenizer/train
POST /api/tokenizer/encode  body: { "text":"hello world" }
POST /api/embeddings/batch  body: { "tokenIds":[...] }
POST /api/transformer/forward body: { "tokenIds":[...] }

This project is for learning and research — not optimized for production.
