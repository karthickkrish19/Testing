namespace LLMModuleApi.Services;
public interface ITokenizerService
{
    int GetVocabSize();
    Task<Dictionary<string,int>> TrainAsync(); // trains from file
    int[] Encode(string text);
    string[] Decode(int[] tokenIds);
}
