namespace LLMModuleApi.Services;
public class LayerNorm
{
    private readonly int _d;
    private readonly float[] _gamma;
    private readonly float[] _beta;
    private readonly float _eps = 1e-5f;
    public LayerNorm(int d)
    {
        _d = d;
        _gamma = new float[d];
        _beta = new float[d];
        for (int i=0;i<d;i++) _gamma[i] = 1f;
    }

    public float[][] Apply(float[][] x)
    {
        int seq = x.Length;
        var outArr = new float[seq][];
        for (int i=0;i<seq;i++)
        {
            outArr[i] = new float[_d];
            float mean = 0;
            for (int j=0;j<_d;j++) mean += x[i][j];
            mean /= _d;
            float var = 0;
            for (int j=0;j<_d;j++){ float t = x[i][j]-mean; var += t*t; }
            var /= _d;
            float denom = (float)Math.Sqrt(var + _eps);
            for (int j=0;j<_d;j++) outArr[i][j] = _gamma[j] * ((x[i][j]-mean)/denom) + _beta[j];
        }
        return outArr;
    }
}
