namespace LLMModuleApi.Services;
public class EmbeddingService : IEmbeddingService
{
    private readonly ITokenizerService _tokenizer;
    private readonly int _embeddingDim = 128;
    private int _vocabSize = 30000;
    private float[,] _embeddings = null!;
    private readonly int _maxSeq = 2048;
    private float[,] _ropeCos = null!;
    private float[,] _ropeSin = null!;

    public EmbeddingService(ITokenizerService tokenizer)
    {
        _tokenizer = tokenizer;
        try
        {
            var vs = _tokenizer.GetVocabSize();
            if (vs > 0) _vocabSize = vs;
        } catch { }
        Init();
    }

    private void Init()
    {
        if (_embeddingDim % 2 != 0) throw new ArgumentException("embedding dim must be even for RoPE");
        _embeddings = new float[_vocabSize, _embeddingDim];
        var rnd = new Random(1234);
        for (int i=0;i<_vocabSize;i++)
            for (int j=0;j<_embeddingDim;j++)
                _embeddings[i,j] = (float)(rnd.NextDouble()*2-1) * 0.02f;

        // precompute RoPE cos/sin for positions up to maxSeq
        _ropeCos = new float[_maxSeq, _embeddingDim/2];
        _ropeSin = new float[_maxSeq, _embeddingDim/2];
        for (int pos=0; pos<_maxSeq; pos++)
        {
            for (int i=0;i<_embeddingDim/2;i++)
            {
                double invFreq = 1.0 / Math.Pow(10000, (2.0*i)/_embeddingDim);
                double angle = pos * invFreq;
                _ropeCos[pos,i] = (float)Math.Cos(angle);
                _ropeSin[pos,i] = (float)Math.Sin(angle);
            }
        }
    }

    public float[][] GetTokenEmbeddingBatch(int[] tokenIds)
    {
        var outArr = new float[tokenIds.Length][];
        for (int t=0;t<tokenIds.Length;t++)
        {
            int id = tokenIds[t];
            if (id < 0 || id >= _vocabSize) id = 1; // unk
            var vec = new float[_embeddingDim];
            for (int j=0;j<_embeddingDim;j++) vec[j] = _embeddings[id,j];
            // apply RoPE in-place per position
            int half = _embeddingDim/2;
            for (int i=0;i<half;i++)
            {
                float x1 = vec[2*i];
                float x2 = vec[2*i+1];
                float cos = _ropeCos[Math.Min(t, _maxSeq-1), i];
                float sin = _ropeSin[Math.Min(t, _maxSeq-1), i];
                vec[2*i]   = x1 * cos - x2 * sin;
                vec[2*i+1] = x1 * sin + x2 * cos;
            }
            outArr[t] = vec;
        }
        return outArr;
    }

    public int GetEmbeddingDim() => _embeddingDim;
    public int GetVocabSize() => _vocabSize;
}
