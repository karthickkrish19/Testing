namespace LLMModuleApi.Services;
public class MultiHeadAttention
{
    private readonly int _dModel;
    private readonly int _numHeads;
    private readonly int _dHead;
    private readonly float[,] _wQ;
    private readonly float[,] _wK;
    private readonly float[,] _wV;
    private readonly float[,] _wO;

    public MultiHeadAttention(int dModel, int numHeads)
    {
        _dModel = dModel;
        _numHeads = numHeads;
        if (_dModel % _numHeads != 0) throw new ArgumentException("dModel must be divisible by numHeads");
        _dHead = _dModel / _numHeads;
        _wQ = Init(_dModel, _dModel);
        _wK = Init(_dModel, _dModel);
        _wV = Init(_dModel, _dModel);
        _wO = Init(_dModel, _dModel);
    }

    // Project (seq x dModel) -> seq x numHeads x dHead
    private float[][][] ProjectSplit(float[][] x, float[,] W)
    {
        int seq = x.Length;
        var proj = new float[seq][][];
        for (int i=0;i<seq;i++)
        {
            var tmp = new float[_dModel];
            for (int j=0;j<_dModel;j++)
            {
                float s = 0;
                for (int k=0;k<_dModel;k++) s += x[i][k] * W[k,j];
                tmp[j] = s;
            }
            proj[i] = new float[_numHeads][];
            for (int h=0; h<_numHeads; h++)
            {
                proj[i][h] = new float[_dHead];
                Array.Copy(tmp, h*_dHead, proj[i][h], 0, _dHead);
            }
        }
        return proj;
    }

    public float[][] ComputeAttention(float[][] x)
    {
        int seq = x.Length;
        var Q = ProjectSplit(x, _wQ);
        var K = ProjectSplit(x, _wK);
        var V = ProjectSplit(x, _wV);

        // per-head attention results: head -> seq x dHead
        var headOut = new float[_numHeads][][];
        for (int h=0; h<_numHeads; h++)
        {
            // scores seq x seq
            var scores = new float[seq][];
            for (int i=0;i<seq;i++)
            {
                scores[i] = new float[seq];
                for (int j=0;j<seq;j++)
                {
                    float dot = 0;
                    for (int d=0; d<_dHead; d++) dot += Q[i][h][d] * K[j][h][d];
                    scores[i][j] = dot / (float)Math.Sqrt(_dHead);
                }
            }
            // softmax rows
            for (int i=0;i<seq;i++)
            {
                float max = scores[i].Max();
                float sum = 0;
                for (int j=0;j<seq;j++){ scores[i][j] = (float)Math.Exp(scores[i][j]-max); sum += scores[i][j]; }
                for (int j=0;j<seq;j++) scores[i][j] /= sum;
            }
            // weighted sum
            headOut[h] = new float[seq][];
            for (int i=0;i<seq;i++)
            {
                headOut[h][i] = new float[_dHead];
                for (int j=0;j<seq;j++)
                {
                    for (int d=0; d<_dHead; d++)
                        headOut[h][i][d] += scores[i][j] * V[j][h][d];
                }
            }
        }

        // concat heads -> seq x dModel
        var concat = new float[seq][];
        for (int i=0;i<seq;i++)
        {
            concat[i] = new float[_dModel];
            for (int h=0; h<_numHeads; h++)
                Array.Copy(headOut[h][i], 0, concat[i], h*_dHead, _dHead);
        }
        // output projection
        return Project(concat, _wO);
    }

    private static float[,] Init(int inDim, int outDim)
    {
        var m = new float[inDim, outDim];
        var rnd = new Random(1337);
        float scale = 1f / (float)Math.Sqrt(inDim);
        for (int i=0;i<inDim;i++) for (int j=0;j<outDim;j++) m[i,j] = (float)(rnd.NextDouble()*2-1) * scale * 0.02f;
        return m;
    }

    private static float[][] Project(float[][] x, float[,] W)
    {
        int seq = x.Length;
        int outDim = W.GetLength(1);
        var res = new float[seq][];
        for (int i=0;i<seq;i++)
        {
            res[i] = new float[outDim];
            for (int j=0;j<outDim;j++)
            {
                float s = 0;
                for (int k=0;k<W.GetLength(0);k++) s += x[i][k] * W[k,j];
                res[i][j] = s;
            }
        }
        return res;
    }
}
