namespace LLMModuleApi.Services;
public interface ITransformerService
{
    float[][] Forward(int[] tokenIds);
}
