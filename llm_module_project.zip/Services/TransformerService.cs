namespace LLMModuleApi.Services;
public class TransformerService : ITransformerService
{
    private readonly IEmbeddingService _emb;
    private readonly int _dModel;
    private readonly int _numHeads;
    private readonly int _dff;
    private readonly int _maxSeq = 1024;

    public TransformerService(IEmbeddingService emb)
    {
        _emb = emb;
        _dModel = emb.GetEmbeddingDim();
        _numHeads = 8;
        if (_dModel % _numHeads != 0) throw new ArgumentException("dmodel must be divisible by numHeads");
        _dff = _dModel * 4;
    }

    // Minimal single-block transformer forward for demonstration
    public float[][] Forward(int[] tokenIds)
    {
        var x = _emb.GetTokenEmbeddingBatch(tokenIds); // seq x dmodel
        int seq = x.Length;
        // Multi-head attention
        var mha = new MultiHeadAttention(_dModel, _numHeads);
        var att = mha.ComputeAttention(x); // seq x dmodel
        // Add & Norm
        var add1 = new float[seq][];
        var ln1 = new LayerNorm(_dModel);
        for (int i=0;i<seq;i++)
        {
            add1[i] = new float[_dModel];
            for (int j=0;j<_dModel;j++) add1[i][j] = x[i][j] + att[i][j];
        }
        add1 = ln1.Apply(add1);
        // FeedForward
        var ff = FeedForward(add1);
        // Add & Norm 2
        var add2 = new float[seq][];
        var ln2 = new LayerNorm(_dModel);
        for (int i=0;i<seq;i++)
        {
            add2[i] = new float[_dModel];
            for (int j=0;j<_dModel;j++) add2[i][j] = add1[i][j] + ff[i][j];
        }
        add2 = ln2.Apply(add2);
        return add2;
    }

    private float[][] FeedForward(float[][] x)
    {
        int seq = x.Length;
        // simple two-layer MLP with GELU-like (approx)
        var w1 = InitMatrix(_dModel, _dff);
        var b1 = new float[_dff];
        var w2 = InitMatrix(_dff, _dModel);
        var b2 = new float[_dModel];
        var outArr = new float[seq][];
        for (int i=0;i<seq;i++)
        {
            var hidden = new float[_dff];
            for (int j=0;j<_dff;j++)
            {
                float sum = b1[j];
                for (int k=0;k<_dModel;k++) sum += x[i][k] * w1[k,j];
                // GELU approx
                hidden[j] = 0.5f * sum * (1 + (float)Math.Tanh(0.79788456 * (sum + 0.044715 * Math.Pow(sum,3))));
            }
            outArr[i] = new float[_dModel];
            for (int j=0;j<_dModel;j++)
            {
                float sum = b2[j];
                for (int k=0;k<_dff;k++) sum += hidden[k] * w2[k,j];
                outArr[i][j] = sum;
            }
        }
        return outArr;
    }

    private static float[,] InitMatrix(int inDim, int outDim)
    {
        var m = new float[inDim, outDim];
        var rnd = new Random(42);
        float scale = 1f / (float)Math.Sqrt(inDim);
        for (int i=0;i<inDim;i++)
            for (int j=0;j<outDim;j++)
                m[i,j] = (float)(rnd.NextDouble()*2-1) * scale * 0.02f;
        return m;
    }
}
