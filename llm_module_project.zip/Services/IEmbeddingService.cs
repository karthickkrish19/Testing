namespace LLMModuleApi.Services;
public interface IEmbeddingService
{
    float[][] GetTokenEmbeddingBatch(int[] tokenIds);
    int GetEmbeddingDim();
    int GetVocabSize();
}
