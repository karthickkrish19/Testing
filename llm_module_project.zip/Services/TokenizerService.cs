using System.Text.Json;
namespace LLMModuleApi.Services;
public class TokenizerService : ITokenizerService
{
    private readonly string _inputPath = "/mnt/data/c#latestVSCodeAI.txt";
    private readonly object _lock = new();
    private Dictionary<string,int> _vocab = new();
    private bool _loaded = false;
    private readonly int _defaultVocab = 30000;

    public TokenizerService()
    {
        // lazy init
    }

    private void EnsureLoaded()
    {
        if (_loaded) return;
        lock(_lock)
        {
            if (_loaded) return;
            // try to load vocab file created by TrainAsync
            var path = Path.Combine(AppContext.BaseDirectory, "wwwroot","data","tokenizer_vocab.json");
            if (File.Exists(path))
            {
                var txt = File.ReadAllText(path);
                _vocab = JsonSerializer.Deserialize<Dictionary<string,int>>(txt) ?? new();
            }
            _loaded = true;
        }
    }

    public int GetVocabSize()
    {
        EnsureLoaded();
        return _vocab.Count > 0 ? _vocab.Count : _defaultVocab;
    }

    public async Task<Dictionary<string,int>> TrainAsync()
    {
        lock(_lock)
        {
            // simple trainer: whitespace tokens + top N unique tokens
            if (!File.Exists(_inputPath))
                throw new FileNotFoundException($"Training file not found at {_inputPath}");
        }
        string text = await File.ReadAllTextAsync(_inputPath);
        text = TokenizerCommon.Clean(text);
        if (string.IsNullOrWhiteSpace(text))
            throw new InvalidOperationException("No text to train on.");

        var counts = new Dictionary<string,int>();
        foreach(var tok in text.Split(' '))
        {
            if (string.IsNullOrWhiteSpace(tok)) continue;
            counts[tok] = counts.GetValueOrDefault(tok,0) + 1;
        }
        // pick top tokens up to default vocab
        var top = counts.OrderByDescending(kv => kv.Value).Take(20000).Select(kv => kv.Key).ToArray();
        var vocab = new Dictionary<string,int>();
        int id = 1; // reserve 0 for padding/unk
        vocab["<pad>"] = 0;
        vocab["<unk>"] = id++;
        foreach(var t in top)
        {
            if (!vocab.ContainsKey(t)) vocab[t] = id++;
        }
        // save to disk
        var outPath = Path.Combine(AppContext.BaseDirectory, "wwwroot","data","tokenizer_vocab.json");
        Directory.CreateDirectory(Path.GetDirectoryName(outPath)!);
        await File.WriteAllTextAsync(outPath, JsonSerializer.Serialize(vocab));
        // reload
        lock(_lock){ _vocab = vocab; _loaded = true; }
        return _vocab;
    }

    public int[] Encode(string text)
    {
        EnsureLoaded();
        text = TokenizerCommon.Clean(text);
        var toks = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var ids = new List<int>();
        foreach(var t in toks)
        {
            if (_vocab.TryGetValue(t, out var id)) ids.Add(id);
            else ids.Add(_vocab.GetValueOrDefault("<unk>", 1));
        }
        return ids.ToArray();
    }

    public string[] Decode(int[] tokenIds)
    {
        EnsureLoaded();
        var inv = _vocab.ToDictionary(kv => kv.Value, kv => kv.Key);
        return tokenIds.Select(i => inv.GetValueOrDefault(i, "<unk>")).ToArray();
    }
}
