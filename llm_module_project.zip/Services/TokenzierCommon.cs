using System.Text.RegularExpressions;
namespace LLMModuleApi.Services;
internal static class TokenizerCommon
{
    internal static string Clean(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        // simple normalization
        s = s.Replace("\r"," ").Replace("\n"," ").Trim().ToLowerInvariant();
        s = Regex.Replace(s, "\\s+", " ");
        return s;
    }
}
