namespace LLMModuleApi.Models;
public record EncodeRequest(string Text);
public record TokenIdsRequest(int[] TokenIds);
