using Microsoft.AspNetCore.Mvc;
using LLMModuleApi.Services;
using LLMModuleApi.Models;

namespace LLMModuleApi.Controllers;
[ApiController]
[Route("api/tokenizer")]
public class TokenizerController : ControllerBase
{
    private readonly ITokenizerService _tokenizer;
    public TokenizerController(ITokenizerService tokenizer) { _tokenizer = tokenizer; }

    [HttpGet("vocabsize")]
    public IActionResult VocabSize() => Ok(new { vocabSize = _tokenizer.GetVocabSize() });

    [HttpPost("train")]
    public async Task<IActionResult> Train()
    {
        var vocab = await _tokenizer.TrainAsync();
        return Ok(new { vocabSize = vocab.Count });
    }

    [HttpPost("encode")]
    public IActionResult Encode([FromBody] EncodeRequest req)
    {
        if (req == null || string.IsNullOrWhiteSpace(req.Text)) return BadRequest("text required");
        var ids = _tokenizer.Encode(req.Text);
        return Ok(new { tokenIds = ids });
    }

    [HttpPost("decode")]
    public IActionResult Decode([FromBody] TokenIdsRequest req)
    {
        if (req == null || req.TokenIds == null) return BadRequest();
        var toks = _tokenizer.Decode(req.TokenIds);
        return Ok(new { tokens = toks });
    }
}
