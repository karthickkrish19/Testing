using Microsoft.AspNetCore.Mvc;
using LLMModuleApi.Services;
using LLMModuleApi.Models;

namespace LLMModuleApi.Controllers;
[ApiController]
[Route("api/transformer")]
public class TransformerController : ControllerBase
{
    private readonly ITransformerService _tr;
    public TransformerController(ITransformerService tr) { _tr = tr; }

    [HttpPost("forward")]
    public IActionResult Forward([FromBody] TokenIdsRequest req)
    {
        if (req==null || req.TokenIds==null) return BadRequest();
        var outVecs = _tr.Forward(req.TokenIds);
        return Ok(new { hidden = outVecs });
    }
}
