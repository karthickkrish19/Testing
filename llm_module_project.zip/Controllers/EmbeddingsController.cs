using Microsoft.AspNetCore.Mvc;
using LLMModuleApi.Services;
using LLMModuleApi.Models;

namespace LLMModuleApi.Controllers;
[ApiController]
[Route("api/embeddings")]
public class EmbeddingsController : ControllerBase
{
    private readonly IEmbeddingService _emb;
    public EmbeddingsController(IEmbeddingService emb) { _emb = emb; }

    [HttpPost("batch")]
    public IActionResult Batch([FromBody] TokenIdsRequest req)
    {
        if (req == null || req.TokenIds == null) return BadRequest();
        var outVecs = _emb.GetTokenEmbeddingBatch(req.TokenIds);
        return Ok(new { embeddings = outVecs, dim = _emb.GetEmbeddingDim() });
    }
}
